#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { marked } from 'marked';
import { program } from 'commander';
import chalk from 'chalk';

// Configure the CLI program
program
  .name('md2html')
  .description('A CLI tool to convert Markdown files to HTML')
  .version('1.0.0')
  .argument('<input>', 'Input Markdown file path')
  .option('-o, --output <path>', 'Output HTML file path')
  .option('-t, --title <title>', 'HTML document title')
  .option('-s, --style <path>', 'Path to custom CSS file')
  .action(async (input, options) => {
    try {
      // Process the input file
      await convertMarkdownFile(input, options);
    } catch (error) {
      console.error(chalk.red('Error:'), error.message);
      process.exit(1);
    }
  });

program.parse();

/**
 * Converts a Markdown file to HTML
 * @param {string} inputPath - Path to the Markdown file
 * @param {Object} options - Command options
 */
async function convertMarkdownFile(inputPath, options) {
  // Check if input file exists
  try {
    await fs.access(inputPath);
  } catch (error) {
    throw new Error(`Input file "${inputPath}" does not exist or is not accessible.`);
  }

  console.log(chalk.blue(`📄 Reading file: ${inputPath}`));

  // Determine the output path
  const outputPath = options.output || 
    path.join(path.dirname(inputPath), 
    `${path.basename(inputPath, path.extname(inputPath))}.html`);

  // Get the document title
  const title = options.title || path.basename(inputPath, path.extname(inputPath));

  // Read the input file
  const markdown = await fs.readFile(inputPath, 'utf-8');
  
  console.log(chalk.blue('🔄 Converting Markdown to HTML...'));

  // Convert markdown to HTML
  const htmlContent = marked.parse(markdown);

  // Read custom CSS if provided
  let customCss = '';
  if (options.style) {
    try {
      customCss = await fs.readFile(options.style, 'utf-8');
      console.log(chalk.blue(`🎨 Applied custom styles from ${options.style}`));
    } catch (error) {
      console.warn(chalk.yellow(`⚠️ Warning: Could not read custom CSS file. Using default styles.`));
    }
  }

  // Generate the full HTML document
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      line-height: 1.6;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      color: #333;
    }
    pre {
      background: #f4f4f4;
      padding: 15px;
      overflow: auto;
      border-radius: 5px;
    }
    code {
      background: #f4f4f4;
      padding: 2px 4px;
      border-radius: 3px;
      font-family: monospace;
    }
    blockquote {
      border-left: 4px solid #ddd;
      padding-left: 15px;
      color: #666;
      margin-left: 0;
    }
    img {
      max-width: 100%;
      height: auto;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 15px 0;
    }
    table, th, td {
      border: 1px solid #ddd;
      padding: 8px;
    }
    th {
      background-color: #f4f4f4;
    }
    h1, h2, h3, h4, h5, h6 {
      margin-top: 24px;
      margin-bottom: 16px;
      font-weight: 600;
      line-height: 1.25;
    }
    a {
      color: #0366d6;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    ${customCss}
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

  // Write the HTML to the output file
  await fs.writeFile(outputPath, html);

  console.log(chalk.green(`✅ Successfully converted to: ${outputPath}`));
}