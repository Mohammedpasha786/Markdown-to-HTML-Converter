# Markdown to HTML Converter CLI

A powerful command-line tool that converts Markdown files to beautifully formatted HTML documents.

## Features

- Convert Markdown files to clean, well-structured HTML
- Support for standard Markdown syntax:
  - Headers (h1-h6)
  - Text formatting (bold, italic, strikethrough)
  - Lists (ordered and unordered)
  - Links and images
  - Code blocks with syntax highlighting
  - Blockquotes
  - Tables
- Custom title setting
- Custom CSS styling option
- Clean, responsive HTML output

## Installation

### Prerequisites

- Node.js (version 14 or higher)
- npm (Node Package Manager)

### Local Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/md2html-cli.git
   cd md2html-cli
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Make the script executable:
   ```bash
   chmod +x index.js
   ```

4. Link the package to use it globally (optional):
   ```bash
   npm link
   ```

### Global Installation (from npm)

Once published to npm, you can install it globally using:

```bash
npm install -g md2html-cli
```

## Usage

### Basic Usage

Convert a Markdown file to HTML using the default settings:

```bash
md2html path/to/input.md
```

This will create an HTML file with the same name at the same location.

### Options

```
Usage: md2html [options] <input>

A CLI tool to convert Markdown files to HTML

Arguments:
  input                Input Markdown file path

Options:
  -V, --version        output the version number
  -o, --output <path>  Output HTML file path
  -t, --title <title>  HTML document title
  -s, --style <path>   Path to custom CSS file
  -h, --help           display help for command
```

### Examples

1. Specify an output file:
   ```bash
   md2html README.md -o output/readme.html
   ```

2. Set a custom title:
   ```bash
   md2html README.md -t "My Project Documentation"
   ```

3. Apply custom CSS:
   ```bash
   md2html README.md -s styles/custom.css
   ```

4. Combine multiple options:
   ```bash
   md2html README.md -o docs/index.html -t "Project Docs" -s styles/docs.css
   ```

## Sample Files

This repository includes sample files to demonstrate the converter:

- `samples/sample.md`: A sample Markdown file showcasing various Markdown features
- `samples/custom-style.css`: A sample CSS file that can be used with the `-s` option

To try the sample:

```bash
md2html samples/sample.md -t "Sample Conversion" -s samples/custom-style.css
```

## Screenshots

![Command line usage](screenshots/cli-usage.png)
*Converting a Markdown file using the command line*

![Output HTML](screenshots/output-html.png)
*The resulting HTML page from the sample Markdown*

## License

MIT