#!/usr/bin/env node

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { marked } from 'marked';
import chalk from 'chalk';

// Get the directory name
const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function generateSamples() {
  console.log(chalk.blue('Generating sample HTML files...'));
  
  // Input paths
  const sampleMarkdownPath = path.join(__dirname, 'samples', 'sample.md');
  const customCssPath = path.join(__dirname, 'samples', 'custom-style.css');
  
  // Output paths
  const defaultHtmlPath = path.join(__dirname, 'samples', 'sample-default.html');
  const styledHtmlPath = path.join(__dirname, 'samples', 'sample-styled.html');
  
  try {
    // Read the markdown and CSS content
    const markdown = await fs.readFile(sampleMarkdownPath, 'utf-8');
    const customCss = await fs.readFile(customCssPath, 'utf-8');
    const htmlContent = marked.parse(markdown);
    
    // Default HTML with basic styling
    const defaultHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sample Markdown - Default Style</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      line-height: 1.6;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      color: #333;
    }
    pre {
      background: #f4f4f4;
      padding: 15px;
      overflow: auto;
      border-radius: 5px;
    }
    code {
      background: #f4f4f4;
      padding: 2px 4px;
      border-radius: 3px;
      font-family: monospace;
    }
    blockquote {
      border-left: 4px solid #ddd;
      padding-left: 15px;
      color: #666;
      margin-left: 0;
    }
    img {
      max-width: 100%;
      height: auto;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 15px 0;
    }
    table, th, td {
      border: 1px solid #ddd;
      padding: 8px;
    }
    th {
      background-color: #f4f4f4;
    }
    h1, h2, h3, h4, h5, h6 {
      margin-top: 24px;
      margin-bottom: 16px;
      font-weight: 600;
      line-height: 1.25;
    }
    a {
      color: #0366d6;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

    // Custom styled HTML
    const styledHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sample Markdown - Custom Style</title>
  <style>
    ${customCss}
  </style>
</head>
<body>
  ${htmlContent}
</body>
</html>`;

    // Write the HTML files
    await fs.writeFile(defaultHtmlPath, defaultHtml);
    await fs.writeFile(styledHtmlPath, styledHtml);
    
    console.log(chalk.green('✅ Sample HTML files generated:'));
    console.log(chalk.white(`   - ${defaultHtmlPath}`));
    console.log(chalk.white(`   - ${styledHtmlPath}`));
    console.log(chalk.yellow('\nYou can use these files as examples of the conversion output.'));
    
  } catch (error) {
    console.error(chalk.red('Error generating sample files:'), error.message);
    process.exit(1);
  }
}

generateSamples();