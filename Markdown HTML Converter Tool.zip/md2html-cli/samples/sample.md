# Markdown to HTML Converter

This is a sample Markdown file to demonstrate the conversion capabilities of our tool.

## Features

The converter supports various Markdown syntax elements:

### Text Formatting

- **Bold text** for emphasis
- *Italic text* for subtle emphasis
- ~~Strikethrough~~ for deleted content
- `inline code` for commands or code snippets

### Lists

Ordered list:
1. First item
2. Second item
3. Third item with **bold text**

Unordered list:
- Apple
- Orange
- Banana
  - Sub-item 1
  - Sub-item 2

### Code Blocks

```javascript
function sayHello(name) {
  console.log(`Hello, ${name}!`);
}

// Call the function
sayHello('World');
```

### Links and Images

[Visit GitHub](https://github.com)

![Sample Image](https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&h=400&fit=crop)

### Blockquotes

> This is a blockquote.
> 
> It can span multiple lines.

### Tables

| Name | Age | Occupation |
|------|-----|------------|
| John | 30  | Developer  |
| Jane | 25  | Designer   |
| Bob  | 35  | Manager    |

## Conclusion

This sample demonstrates most of the Markdown features that our converter supports.