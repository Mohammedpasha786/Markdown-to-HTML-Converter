# Contributing to Markdown to HTML CLI Converter

Thank you for your interest in contributing to this project! Here's how you can help.

## Development Setup

1. Fork the repository
2. Clone your fork locally
3. Install dependencies with `npm install`
4. Make your changes
5. Test your changes locally

## Testing

Before submitting a pull request, ensure:

1. The tool works correctly with your changes
2. All existing functionality remains intact
3. Your code follows the project's style and conventions

Test with a variety of Markdown files to ensure compatibility.

## Pull Request Process

1. Update the README.md with details of changes if applicable
2. Update the samples or add new samples if you've added features
3. Submit your pull request with a clear description of the changes

## Code Style

- Use modern JavaScript features (ES6+)
- Follow the existing code style and patterns
- Add comments for complex logic
- Use descriptive variable and function names

## Feature Requests and Bug Reports

Please use the GitHub issue tracker to submit feature requests and bug reports.

When reporting bugs, please include:
- A clear description of the issue
- Steps to reproduce
- Expected behavior
- Actual behavior
- Sample Markdown file that demonstrates the issue (if applicable)

## License

By contributing to this project, you agree that your contributions will be licensed under the same license as the project (MIT).