This directory is for storing screenshots of the md2html CLI tool in action.

Suggested screenshots to add:
1. CLI usage and successful conversion output
2. The HTML output viewed in a browser
3. Before/after comparison of Markdown and rendered HTML
4. Demonstration of custom CSS styling options

When preparing screenshots:
- Use clear, readable terminal output
- Choose a clean browser environment for HTML display
- Use the sample.md file to demonstrate the conversion features
- Show both light and dark theme variations if possible