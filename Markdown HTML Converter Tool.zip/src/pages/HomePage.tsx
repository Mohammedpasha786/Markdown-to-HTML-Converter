import { FileText, FileDown, ArrowRight } from 'lucide-react';
import { MarkdownConverter } from '@/components/MarkdownConverter';

function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <header className="container mx-auto pt-12 pb-8 px-4 text-center">
        <div className="flex items-center justify-center gap-3 mb-3">
          <FileText className="h-8 w-8 text-primary" />
          <FileDown className="h-6 w-6 text-primary" strokeWidth={2.5} />
          <ArrowRight className="h-5 w-5 text-primary" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight">Markdown to HTML Converter</h1>
        <p className="mt-3 text-xl text-muted-foreground max-w-2xl mx-auto">
          Transform your Markdown files into clean, well-formatted HTML with just a few clicks
        </p>
      </header>

      <main>
        <MarkdownConverter />
      </main>
      
      <footer className="container mx-auto mt-16 mb-8 px-4 text-center text-sm text-muted-foreground">
        <p>Markdown to HTML Converter • Supports standard Markdown syntax</p>
        <p className="mt-1">
          <span className="inline-flex items-center gap-1">
            <span>Powered by </span>
            <a 
              href="https://marked.js.org/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="underline underline-offset-2 hover:text-primary transition-colors"
            >
              marked
            </a>
          </span>
        </p>
      </footer>
    </div>
  );
}

export default HomePage;