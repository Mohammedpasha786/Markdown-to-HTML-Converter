import React from 'react';
import { Card } from '@/components/ui/card';
import { FileCode } from 'lucide-react';

interface OutputDisplayProps {
  html: string;
}

export function OutputDisplay({ html }: OutputDisplayProps) {
  if (!html) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <FileCode className="w-12 h-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium">HTML Preview</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Convert your Markdown to see the HTML output here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-medium">HTML Preview</h3>
      </div>

      <div className="bg-secondary p-4 rounded-md overflow-auto max-h-[500px]">
        <pre className="text-xs text-muted-foreground">
          <code>{html.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</code>
        </pre>
      </div>

      <Card className="border rounded-md p-6 bg-white">
        <div
          className="prose prose-sm max-w-full markdown-preview"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      </Card>
    </div>
  );
}