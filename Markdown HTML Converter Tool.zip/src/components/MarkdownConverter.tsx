import { useState, useEffect } from 'react';
import { marked } from 'marked';
import { FileUpload } from '@/components/FileUpload';
import { OutputDisplay } from '@/components/OutputDisplay';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileDown, ArrowRight, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function MarkdownConverter() {
  const [markdown, setMarkdown] = useState<string>('');
  const [html, setHtml] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    async function convertMarkdown() {
      try {
        if (markdown.trim()) {
          // Handle the possibility that marked.parse returns a Promise
          const convertedHtml = await Promise.resolve(marked.parse(markdown));
          setHtml(convertedHtml);
        } else {
          setHtml('');
        }
      } catch (error) {
        toast({
          title: "Conversion Error",
          description: "Failed to convert markdown. Please check your input.",
          variant: "destructive"
        });
      }
    }
    
    convertMarkdown();
  }, [markdown, toast]);

  const handleFileUpload = (content: string, name: string) => {
    setMarkdown(content);
    setFileName(name.replace(/\.md$/, ''));
    toast({
      title: "File Loaded",
      description: `${name} has been successfully loaded.`
    });
  };

  const downloadHtml = () => {
    if (!html) {
      toast({
        title: "Nothing to download",
        description: "Please convert some markdown content first.",
        variant: "destructive"
      });
      return;
    }

    const outputFileName = fileName || 'converted';
    const blob = new Blob([
      '<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n<title>' +
      outputFileName +
      '</title>\n<style>\nbody { font-family: system-ui, -apple-system, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px; }\npre { background: #f4f4f4; padding: 15px; overflow: auto; border-radius: 5px; }\ncode { background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }\nblockquote { border-left: 4px solid #ddd; padding-left: 15px; color: #666; }\nimg { max-width: 100%; }\ntable { border-collapse: collapse; width: 100%; }\ntable, th, td { border: 1px solid #ddd; padding: 8px; }\n</style>\n</head>\n<body>\n' +
      html +
      '\n</body>\n</html>'
    ], { type: 'text/html;charset=utf-8' });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${outputFileName}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Complete",
      description: `${outputFileName}.html has been downloaded.`
    });
  };

  const clearContent = () => {
    setMarkdown('');
    setHtml('');
    setFileName('');
    toast({
      title: "Content Cleared",
      description: "All content has been cleared."
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Tabs defaultValue="input" className="max-w-4xl mx-auto">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="input">Input</TabsTrigger>
          <TabsTrigger value="output">Output</TabsTrigger>
        </TabsList>
        
        <TabsContent value="input" className="space-y-6">
          <Card className="p-6">
            <FileUpload onFileLoaded={handleFileUpload} />
            <div className="mt-6">
              <textarea
                value={markdown}
                onChange={(e) => setMarkdown(e.target.value)}
                placeholder="# Type or paste your markdown here&#10;&#10;## Subheading&#10;&#10;This is a paragraph with **bold** and *italic* text.&#10;&#10;- List item 1&#10;- List item 2"
                className="w-full h-80 p-4 border border-gray-300 rounded-md font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            
            <div className="flex justify-between mt-4">
              <Button onClick={clearContent} variant="outline" className="gap-2">
                <RefreshCw size={16} />
                Clear
              </Button>
              <Button onClick={downloadHtml} className="gap-2">
                <ArrowRight size={16} />
                Convert & Preview
              </Button>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="output" className="space-y-6">
          <Card className="p-6">
            <OutputDisplay html={html} />
            
            <div className="flex justify-end mt-4">
              <Button onClick={downloadHtml} className="gap-2">
                <FileDown size={16} />
                Download HTML
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}